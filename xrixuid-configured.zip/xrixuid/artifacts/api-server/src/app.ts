import path from "node:path";
import fs from "node:fs";
import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import fbRouter from "./routes/fb";
import adminRouter from "./routes/admin";
import { logger } from "./lib/logger";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api/fb", fbRouter);
app.use("/api/admin", adminRouter);
app.use("/api", router);

// --- Serve the built web frontend (single-host deploys: Railway / Render / a VPS) ---
// On Replit the web is a separate static artifact served at "/", so this block stays
// dormant there. It only activates when a production web build is present next to the
// server (default location below) or when WEB_DIST points to a build directory.
const webDir = process.env["WEB_DIST"]
  ? path.resolve(process.env["WEB_DIST"])
  : path.resolve(__dirname, "../../uid-web/dist/public");

if (fs.existsSync(path.join(webDir, "index.html"))) {
  app.use(express.static(webDir));
  // SPA fallback: serve index.html for any non-API GET route so client-side
  // routing (wouter) works on refresh / deep links.
  app.use((req, res, next) => {
    if (req.method !== "GET" || req.path.startsWith("/api")) {
      next();
      return;
    }
    res.sendFile(path.join(webDir, "index.html"));
  });
  logger.info({ webDir }, "Serving web frontend from static build");
}

export default app;
