# XRIXUID AWS EC2 deployment

Ubuntu 24.04, Node 24, pnpm, PostgreSQL and Nginx required.

1. Back up existing application and database before deployment.
2. Copy this repository to /opt/xrixuid and install dependencies: `corepack enable && pnpm install --frozen-lockfile`.
3. Create a dedicated PostgreSQL role/database and store DATABASE_URL, ADMIN_KEY, PORT=3000 and NODE_ENV=production in `/etc/xrixuid/xrixuid.env` (0600 permissions). Never commit this file.
4. Build: `pnpm run build:deploy`.
5. Review schema and take pg_dump backup before any migration. On a fresh empty database only: `pnpm --filter @workspace/db run push`.
6. Ensure runtime write access to `artifacts/api-server/data`, then install the systemd unit and Nginx config in this folder.
7. Verify `curl -f http://127.0.0.1:3000/api/health` and Nginx HTTP response before DNS changes.
8. Point Cloudflare uid.xeroxhub.site A record to the EC2 public IP, enable TLS with a valid origin certificate and Cloudflare Full (strict), then verify external HTTPS.

Do not overwrite existing databases, environment files, or app directories without a backup and inspection.
