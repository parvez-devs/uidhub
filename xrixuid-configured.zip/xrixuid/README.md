# UID Operator

A mobile-first web app for bulk-checking Facebook UIDs. Paste a list of UIDs
(optionally `uid|password` per line), fetch each public profile (name, username,
picture, follower count, Instagram presence) through the API, then review, copy,
star, and export the results. User data is kept in the browser (`localStorage`);
the backend only performs the Facebook lookups and anonymous usage tracking.

## Tech stack

- pnpm workspaces monorepo, Node.js 24, TypeScript 5.9
- **Web** (`artifacts/uid-web`): React + Vite + Tailwind CSS v4 + wouter + shadcn/ui
- **API** (`artifacts/api-server`): Express 5 (undici + cheerio for Facebook fetches)
- **Database**: PostgreSQL + Drizzle ORM (`lib/db`)

## Project layout

| Path | What it is |
| --- | --- |
| `artifacts/uid-web` | React/Vite web frontend (served at `/`) |
| `artifacts/api-server` | Express API (`/api/...`); on external hosts it also serves the web build |
| `lib/db` | Drizzle schema + Postgres client (`@workspace/db`) |

## Environment variables

| Name | Required | Used by | Notes |
| --- | --- | --- | --- |
| `DATABASE_URL` | yes | api-server, db | Postgres connection string |
| `PORT` | yes | api-server, web | Port to listen on (hosting platforms provide this automatically) |
| `BASE_PATH` | web build/dev | web | URL base path; use `/` for standalone hosts |
| `ADMIN_KEY` | recommended | api-server | Unlocks `GET /api/admin/events`. Default is `adbc4231` — **change it** |
| `WEB_DIST` | optional | api-server | Override the path to the web build the API serves |

Secrets (`DATABASE_URL`, `ADMIN_KEY`) are **not** committed to git — set them on
each host you deploy to.

## Run locally (or on Replit)

```bash
pnpm install
pnpm --filter @workspace/api-server run dev   # API (listens on :8080)
pnpm --filter @workspace/uid-web run dev       # web (proxies /api -> :8080)
```

Typecheck / build everything:

```bash
pnpm run typecheck
pnpm run build
```

## Rebuild from scratch on any machine

```bash
git clone <your-repo-url>
cd <repo>
pnpm install
# point DATABASE_URL at a Postgres instance, then create the tables:
DATABASE_URL=... pnpm --filter @workspace/db run push
```

## Deploy to a single external host (Railway / Render / VPS)

On external hosts the Express API also serves the built web frontend, so the
whole app runs as **one Node service**:

- **Build:** `pnpm install --frozen-lockfile && pnpm run build:deploy`
- **Start:** `pnpm run start:deploy`
- **Env:** `DATABASE_URL`, `ADMIN_KEY`, `NODE_ENV=production` (the host provides `PORT`)
- **Create tables once:** `pnpm --filter @workspace/db run push-force`

`build:deploy` builds the web with `BASE_PATH=/` and then builds the API; at
runtime the API automatically serves `artifacts/uid-web/dist/public`.

> **Schema note:** `push-force` creates/updates the tables non-interactively,
> which is ideal for the first deploy. It re-runs on every build — safe here
> because all personal data lives in the browser (only anonymous usage events
> are stored in Postgres). For apps with critical database data, prefer a
> one-time manual schema step instead of running it on every build.

### Render (easiest — uses `render.yaml`)

1. Push this repo to GitHub.
2. In Render: **New → Blueprint**, select the repo. It reads `render.yaml`
   (one web service + a Postgres database) automatically.
3. Set `ADMIN_KEY` when prompted, then **Deploy**.

### Railway

1. Push this repo to GitHub.
2. Railway: **New Project → Deploy from GitHub repo**.
3. Add a database: **New → Database → PostgreSQL** (this sets `DATABASE_URL`).
4. In the service **Settings → Deploy**:
   - **Build command:** `pnpm install --frozen-lockfile && pnpm run build:deploy && pnpm --filter @workspace/db run push-force`
   - **Start command:** `pnpm run start:deploy`
   - **Variables:** `NODE_ENV=production`, `ADMIN_KEY=<your-key>` (`DATABASE_URL` and `PORT` are provided by Railway).
5. Deploy.

## Use an external database (Neon / Supabase)

The app reads `DATABASE_URL`, so any Postgres works:

1. Create a free database at [Neon](https://neon.tech) or [Supabase](https://supabase.com).
2. Copy its connection string into `DATABASE_URL`.
3. Create the tables: `DATABASE_URL=... pnpm --filter @workspace/db run push`.

## Database backup, export & restore

Requires the PostgreSQL client tools (`pg_dump`, `psql`).

```bash
# Full backup (schema + data) into a file
pg_dump "$DATABASE_URL" > backup.sql

# Data only (no schema) — pair this with `db push` on the target
pg_dump --data-only "$DATABASE_URL" > data-only.sql
```

Restore — pick **one** of these (don't mix them):

```bash
# Option A: restore a full backup into a brand-new EMPTY database.
#           Do NOT create the tables first — the dump already includes them.
psql "$NEW_DATABASE_URL" < backup.sql

# Option B: create the schema with Drizzle first, then load only the data.
DATABASE_URL="$NEW_DATABASE_URL" pnpm --filter @workspace/db run push
psql "$NEW_DATABASE_URL" < data-only.sql
```

To migrate from Replit's database to an external one, Option A is simplest:
`pg_dump` the old `DATABASE_URL`, create an **empty** database at your new
provider, then restore `backup.sql`. Keep periodic `backup.sql` files somewhere
safe (e.g. your computer or cloud storage).

## Note on Facebook fetching

Profile data is scraped from Facebook, which can rate-limit or block requests
coming from datacenter IPs (common on Railway/Render/most clouds). If profiles
stop resolving after moving to an external host, you'll likely need an outbound
proxy for the API server.
